﻿var arr_so = new Array();//lưu giá trị số
var arr_tt = new Array();//lưu toán tử
var kq = false;//bấm = hay chưa
var am = false;//kiểm tra số âm hay dương ?
//Học ngu nên chưa nghĩ ra thuật toán dễ hơn :))
function xoa_mang() {//Xoá các giá trị có trong 2 mảng
    while (arr_so.length > 0) {
        arr_so.pop();
    }
    while (arr_tt.length > 0) {
        arr_tt.pop();
    }
}
function nhap(i) {
    var x = document.getElementById("main").getElementsByClassName("display")[0];
    if (eval(x.value) == 0) {
        x.value = i;
    }
    else {
        if (am == false)
            x.value = eval(x.value) * 10 + i;
        else
            x.value = eval(x.value) * 10 - i;
    }
}
function phantram() {
    var x = document.getElementById("main").getElementsByClassName("display")[0];
    x.value = eval(x.value) / 100;
}
function doi_dau() {//bấm +/-
    var x = document.getElementById("main").getElementsByClassName("display")[0];
    x.value = eval(x.value) * (-1);
    if (am == false)//âm là false, dương là true
        am = true;
    else
        am = false;
}
function nhap_clear() {
    document.getElementById("main").getElementsByClassName("display")[0].value = 0;
    xoa_mang();
    kq = false;
}
function nhap_tt(i) {
    var x = eval(document.getElementById("main").getElementsByClassName("display")[0].value);
    arr_so.push(x);
    arr_tt.push(i);
    document.getElementById("main").getElementsByClassName("display")[0].value = 0;
}
function tinhtoan(a, s, b) {
    if (s == '+') {
        return a + b;
    }
    if (s == '-') {
        return a - b;
    }
    if (s == '*') {
        return a * b;
    }
    if (s == '/') {
        return a / b;
    }
    if (s == '^') {
        return a ** b;
    }
}
function ketqua() {
    var x = eval(document.getElementById("main").getElementsByClassName("display")[0].value);
    arr_so.push(x);
    var n = arr_tt.length;
    var a, b, s, c, p;
    //chuyển dấu - thành + hết
    for (var i = 0; i < n; i++) {
        if (arr_tt[i] == '-') {
            arr_so[i + 1] = arr_so[i + 1] * (-1);
            arr_tt[i] = '+';
        }
    }
    while (arr_tt.length > 0) {
        if (arr_tt[n - 1] == '+') {
            if (arr_tt[n - 2] == '*' || arr_tt[n - 2] == '/' || arr_tt[n - 2] == '^') {
                c = arr_so.pop();//giữ lại
                a = arr_so.pop();//tính toán
                b = arr_so.pop();//tính toán
                p = arr_tt.pop();//giữ lại
                s = arr_tt.pop();//tính toán
                arr_so.push(tinhtoan(b, s, a));//tính xong thì push ngược vào
                arr_so.push(c);//tính xong thì push ngược vào
                arr_tt.push(p);//tính xong thì push ngược vào
            }
            else {
                a = arr_so.pop();//tính toán
                b = arr_so.pop();//tính toán
                s = arr_tt.pop();//tính toán
                arr_so.push(tinhtoan(b, s, a));//tính xong thì push ngược vào
            }
        }
        else {
            a = arr_so.pop();//tính toán
            b = arr_so.pop();//tính toán
            s = arr_tt.pop();//tính toán
            arr_so.push(tinhtoan(b, s, a));//tính xong thì push ngược vào
        }
        n--;
    }
    document.getElementById("main").getElementsByClassName("display")[0].value = arr_so[0];
    kq = true;
    xoa_mang();//tính kết quả xong thì xoá 2 mảng
}